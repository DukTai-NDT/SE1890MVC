/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import entity.EmployeeTerritories;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Vector;
import model.DAOEmployeeTerritories;

/**
 *
 * @author Admin
 */
@WebServlet(name = "EmployeeTerritoryController", urlPatterns = {"/EmployeeTerritoryURL"})
public class EmployeeTerritoryController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        DAOEmployeeTerritories dao = new DAOEmployeeTerritories();
        String sql = "SELECT * FROM  EmployeeTerritories ";
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String service = request.getParameter("service");
            if(service.equals("deleteEmployeeTerritory")){
                dao.deleteEmployeeTerr(Integer.parseInt(request.getParameter("employeeID")), 
                           request.getParameter("territoryID") );
                response.sendRedirect("EmployeeTerritoryURL?service=listAllEmployeeTerritory");
            }
            if (service.equals("insertEmployeeTerritory")) {
                String EmployeeID = request.getParameter("EmployeeID");
                String TerritoryID = request.getParameter("TerritoryID");

                int EmployeeId = Integer.parseInt(EmployeeID);
                int n = dao.addEmployeeTerr(new EmployeeTerritories(EmployeeId, TerritoryID));
                response.sendRedirect("EmployeeTerritoryURL?service=listAllEmployeeTerritory");

            }
            if (service.equals("listAllEmployeeTerritory")) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet EmployeeTerritoryController</title>");
                out.println("</head>");
                out.println("<body>");
                out.print(" <form action=\"EmployeeTerritoryURL\" method=\"get\">\n"
                        + "        <p>Search name : <input type=\"text\" name = \"etname\" id =\"\">\n"
                        + "        <input type=\"submit\" value=\"Search\" name=\"submit\">\n"
                        + "        <input type=\"reset\" value=\"reset\" name=\"clean\">\n"
                        + "        <input type=\"hidden\" value=\"listAllEmployeeTerritory\" name=\"service\">\n"
                        + "        </p>\n"
                        + "    </form>");
                out.print("    <p><a href=\"HTML/insertEmployeeTerritory.html\">insert EmployeeTerritory</a></p>");
                out.print(" <table>\n"
                        + "        <tr>\n"
                        + "            <th>EmployeeID</th>\n"
                        + "            <th>TerritoryID</th>\n"
                        + "            <th>update</th> "
                        + "            <th>delete</th> "
                        + "\n"
                        + "\n"
                        + "        </tr>");
                String submit = request.getParameter("submit");
                if (submit == null) {
                    sql = "SELECT * FROM  EmployeeTerritories ";
                } else {
                    String etname = request.getParameter("etname");
                    sql = "SELECT * FROM  EmployeeTerritories where  EmployeeID = " + etname;
                }
                Vector<EmployeeTerritories> vector = dao.getEmployeeTerritorieses(sql);
                for (EmployeeTerritories employeeTerritories : vector) {
                    out.print("<tr>\n"
                            + "            <td>" + employeeTerritories.getEmployeeID() + "</td>\n"
                            + "            <td>" + employeeTerritories.getTerritoryID() + "</td>\n"
                            + "            <td> </td>\n"
                            + "            <td> <p><a href=\"EmployeeTerritoryURL?service=deleteEmployeeTerritory&employeeID="+employeeTerritories.getEmployeeID()+"&territoryID ="+employeeTerritories.getTerritoryID()+"\">Delete </a> </td>\n"
                            + "\n"
                            + "        </tr> ");
                }
                out.print("</table>");
                out.println("<h1>Servlet EmployeeTerritoryController at " + request.getContextPath() + "</h1>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
